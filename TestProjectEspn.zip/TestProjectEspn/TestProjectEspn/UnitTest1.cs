using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace TestProjectEspn
{
    public class Tests
    {
        WebDriver driver;
        [SetUp]
        public void Setup()
        {
           

            driver = new ChromeDriver();
        }

        [Test]
        public void Signup()
        {
            WebElement element = (WebElement)driver.FindElement(By.Id("//*[@id='sideLogin - left - rail']/button[1]"));
            WebElement signupbox = (WebElement)driver.FindElement(By.Id("//*[@id='did - ui - view']/div/section/section/h2"));

            element.Click();
            Thread.Sleep(20000);

            if (signupbox.Displayed)
            {
                //Username
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section[1]/div[1]/div[1]/label/span[2]/input")).SendKeys("Henrik");
                //Lastname
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section[1]/div[1]/div[2]/label/span[2]/input")).SendKeys("Y");
                //email id
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section[1]/div[2]/div/label/span[2]/input")).SendKeys("henriklawrence@gmail.com");
                //password
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section[1]/div[4]/div[1]/label/span[2]/input")).SendKeys("Password234");

  
                //signup button
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section[6]/div/button")).Click();

                Thread.Sleep(30000);

                var  Message =   driver.FindElement(By.XPath("//*[@id='global - header']/div[2]/ul/li[2]/div/div/ul[1]/li[1]/span")).Text;


                Assert.AreEqual("Welcome Henry", Message);

      

            }
        }
        [Test]
        public void Login()
        {
            WebElement login = (WebElement)driver.FindElement(By.XPath("//*[@id='sideLogin - left - rail']/button[2]"));
            WebElement loginbox = (WebElement)driver.FindElement(By.XPath("//*[@id='did - ui - view']/div"));

            login.Click();
            Thread.Sleep(20000);

            if (loginbox.Displayed)
            {
                // Username
                driver.FindElement(By.XPath("//*[@id='did-ui-view']/div/section/section/form/section/div[1]/div/label/span[2]/input")).SendKeys("henriklawrence@gmail.com");
                //password
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section/div[2]/div/label/span[2]/input")).SendKeys("Godzilla@95");


                //login button
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section/div[3]/button")).Click();

                Thread.Sleep(30000);

                var Message = driver.FindElement(By.XPath("//*[@id='global - header']/div[2]/ul/li[2]/div/div/ul[1]/li[1]/span")).Text;


                Assert.AreEqual("Welcome Henry", Message);


            }
        }
        public void Search()
        {
            WebElement login = (WebElement)driver.FindElement(By.XPath("//*[@id='sideLogin - left - rail']/button[2]"));
            WebElement loginbox = (WebElement)driver.FindElement(By.XPath("//*[@id='did - ui - view']/div"));

            login.Click();
            Thread.Sleep(20000);

            if (loginbox.Displayed)
            {
                // Username
                driver.FindElement(By.XPath("//*[@id='did-ui-view']/div/section/section/form/section/div[1]/div/label/span[2]/input")).SendKeys("henriklawrence@gmail.com");
                //password
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section/div[2]/div/label/span[2]/input")).SendKeys("Godzilla@95");


                //login
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section/div[3]/button")).Click();

                Thread.Sleep(30000);
                //search
                driver.FindElement(By.XPath("//*[@id='global - search']/label")).Click();

                Thread.Sleep(2000);

                WebElement input = (WebElement)driver.FindElement(By.XPath("//*[@id='global - search']/label"));

                if (input.Displayed)
                {
                    driver.FindElement(By.XPath("//*[@id='global - search']/label")).SendKeys("IPL");

                    Thread.Sleep(1000);

                    driver.FindElement(By.Id("global-search-input")).Submit();
                }


                var Url = driver.Url;


                Assert.AreEqual("https://www.espn.in/search/_/q/ipl", Url);


            }
        }

        public void Follow()
        {
            WebElement login = (WebElement)driver.FindElement(By.XPath("//*[@id='sideLogin - left - rail']/button[2]"));
            WebElement loginbox = (WebElement)driver.FindElement(By.XPath("//*[@id='did - ui - view']/div"));

            login.Click();
            Thread.Sleep(20000);

            if (loginbox.Displayed)
            {
                // Username
                driver.FindElement(By.XPath("//*[@id='did-ui-view']/div/section/section/form/section/div[1]/div/label/span[2]/input")).SendKeys("henriklawrence@gmail.com");
                //password
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section/div[2]/div/label/span[2]/input")).SendKeys("Godzilla@95");


                //login
                driver.FindElement(By.XPath("//*[@id='did - ui - view']/div/section/section/form/section/div[3]/button")).Click();

                Thread.Sleep(30000);
                //search
                driver.FindElement(By.XPath("//*[@id='global - search']/label")).Click();

                Thread.Sleep(2000);

                WebElement input = (WebElement)driver.FindElement(By.XPath("//*[@id='global - search']/label"));

                if (input.Displayed)
                {
                    driver.FindElement(By.XPath("//*[@id='global - search']/label")).SendKeys("IPL");

                    Thread.Sleep(1000);

                    driver.FindElement(By.Id("global-search-input")).Submit();
                }

                //Add favourite sports-Edit
                driver.FindElement(By.LinkText("Edit")).Click();

                Thread.Sleep(1000);
                 
                //Follow up

                WebElement FavouriteBox = (WebElement)driver.FindElement(By.XPath("//*[@id='fittPortal_0']/div/div/section/div/div/section/div"));


                if (FavouriteBox.Displayed)
                {
                    driver.FindElement(By.XPath("//*[@id='fittPortal_0']/div/div/section/div/div/section/div/section/section[1]/div/ul[2]/li[2]/div[2]/div/button")).Click();
                }


                var Cricket = driver.FindElement(By.XPath("//*[@id='fittPortal_0']/div/div/section/div/div/section/div/section/section[2]/div[1]/ul[3]/li[5]/div[1]/div[2]/h2")).Text;


                Assert.AreEqual("Cricket", Cricket);



            }
        }

        [TearDown]
        public void close()
        {
            driver.Quit();
        }
    }
}